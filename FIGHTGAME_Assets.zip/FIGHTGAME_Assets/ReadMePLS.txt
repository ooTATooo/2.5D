FIGHT GAME ASSET PACK 
by Thomas Lean


_______


Hey :)


THANK U FOR PURCHASING!

Here are some infos & pro tips about the different elements of the asset pack:

- Some animations are just composed of 1 frame (jump, etc), the best way to make them look good in the engine is to time them right! That's why I made gifs & the mockup to help you see how to time all these animations (samurai attacks, etc).

- Feel free to use assets for something else than what they were created in the first place! For example the smoke FXs could be used to make sand FXs or dust FXs when a character walks or hits the ground.

- The fog color in the "BACKGROUND" folder can be used to separate the background between different layers and simulate depth (atmospheric perspective, etc), it will work well with parallax too!).

- For the "POSTPRO" folder, the 2 colored images can be put on the camera of your game. their names (lineardodge & overlay) are the blending modes used in Photoshop to make them look good (these blending modes are also available on Construct or Unity for example).


Have a nice day :) 
